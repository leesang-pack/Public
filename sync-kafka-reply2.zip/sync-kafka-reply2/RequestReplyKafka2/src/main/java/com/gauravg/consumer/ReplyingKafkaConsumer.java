package com.gauravg.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gauravg.model.MessageBinder;
import com.gauravg.model.TargetUserBinder;
import com.gauravg.util.CompletableFutureReplyingKafkaOperations;
import com.gauravg.util.CompletableFutureReplyingKafkaTemplate;
import org.apache.kafka.clients.Metadata;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.Cluster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

//import org.springframework.cloud.stream.annotation.StreamListener;

import com.gauravg.model.Model;

import java.io.IOException;


@Component
public class ReplyingKafkaConsumer {

	@Value("${kafka.topic.request-topic}")
	private String requestTopic;

	////////////////////////////////////////////////////////////////
	// sync test
	// 2.3.x  spring kafka에서 ConsumerRecord<String, Model> _data가 안됨.
	// batch로 commit할때,
	// consumer 다운 시 남아 있는 consumer에서 토픽 rebalance를 한다.
	//  batch로 ack commit할 때, batch 전의 메세지는 commit이 안되었기 때문에 중복으로 메세지가 처리됨.
	//  batch시간을 줄이면 확률적이기 자동 commit사용안함.
	//  수동으로 commit처리. 메세지를 받으면 즉시 commit으로 함.

	@KafkaListener(topics = "${kafka.topic.request-topic}")
	@SendTo
	public Model listen(Model model, Acknowledgment acknowledgment) throws InterruptedException {
//	public Model listen(ConsumerRecord<String, Model> _data, Acknowledgment acknowledgment) throws InterruptedException {

//		ConsumerRecord<String, Model> data = _data;

		System.out.println("=================SERVER RECV START!!!!!!!!!!!!!!!" +model);
//		System.out.println("=================SERVER RECV START!!!!!!!!!!!!!!!" +data.value());

//		System.out.println("=================SERVER END!!!!!! RETURN:::" + data.value().getFirstNumber());
		System.out.println("=================SERVER END!!!!!! RETURN:::" + model.getFirstNumber());

		acknowledgment.acknowledge();

		return model;
//		return data.value();

	}
	// sync END

	////////////////////////////////////////////////////////////////
	// Async Group test
	@SendTo
	@KafkaListener(topics = "${kafka.topic.request-topic2}")
//	public Model Grouplisten(ConsumerRecord<String, Model> data) throws InterruptedException {
	public Model Grouplisten(Model data, Acknowledgment acknowledgment) throws InterruptedException {

		System.out.println("=================SERVER GROUP RECV START!!!!!!!!!!!!!!!"+ data);

		System.out.println("=================SERVER GROUP END!!!!!! RETURN:::" + data.getFirstNumber());
		return data;
	}
	// Async Group END

	////////////////////////////////////////////////////////////////
	// Stream
	// StreamListener는 TargetUserBinder.INPUT입니다. 메시지가 kafka에 들어가면 ReplyingKafkaConsumer 수신하고 targetHandle()에서 소비 메시지를 처리합니다.
	// TargetUserBinder.INPUT가 입력되고, 결합의 이름을 지정하는 input것이 spring.cloud.stream.bindings.target-in이며, 상기 프로파일에 대응
//	@StreamListener(TargetUserBinder.TARGET_IN)
//	@SendTo(MessageBinder.PROCESS_OUT)
//	public Model targetHandle(@Payload Model model) {
//		System.out.println("Target Received: " + model + " " + model.getFirstNumber());
//		model.setFirstNumber(model.getFirstNumber()+1);
//		return model;
//	}

	// 같은 토픽으로 다른 group에서 소비만 할때 사용해야함.
	// sendTo하면 다른 StreamListener가 다시 받게 된다.
//	@StreamListener(TargetUserBinder.TARGET_IN)
//	public void targetHandle(@Payload Model model) {
//		System.out.println("Target Received: " + model + " " + model.getFirstNumber());
//	}

	//MessageBinder.PROCESS_OUT 보낸후 MessageBinder.PROCESS_IN으로 받습니다.
	//위의 SendTo를 통해 전송되는 처리 된 메시지입니다.
//	@StreamListener(MessageBinder.PROCESS_IN)
//	public void messageHandle(@Payload Model model) {
//		System.out.println("Message Received: " + model + " " + model.getFirstNumber());
//	}

	@StreamListener("errorChannel")
	public void error(Message<?> message) {
		System.out.println("Global Error Handling !" + message);
	}
	// Stream END

	@StreamListener(TargetUserBinder.TARGET_IN)
//	@SendTo(MessageBinder.PROCESS_OUT)
//	public Model targetHandle(Message<?> message) {
		public void targetHandle(Message<?> message) {
		Acknowledgment acknowledgment = message.getHeaders().get(KafkaHeaders.ACKNOWLEDGMENT, Acknowledgment.class);
		System.out.println("==============> " + message.getPayload());
		ObjectMapper objectMapper = new ObjectMapper();
		Model model = null;
		try {
			model = objectMapper.readValue(message.getPayload().toString(), Model.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Target Received: " + model + " " + model.getFirstNumber());
		model.setFirstNumber(model.getFirstNumber()+1);
		if (acknowledgment != null) {
			System.out.println("Target Acknowledgment provided");
			acknowledgment.acknowledge();
		}
//		return model;
	}


	@StreamListener(MessageBinder.PROCESS_IN)
	public void messageHandle(Message<?> message) {
		Acknowledgment acknowledgment = message.getHeaders().get(KafkaHeaders.ACKNOWLEDGMENT, Acknowledgment.class);
		System.out.println("============== INNNN > " + message.getPayload());
		if (acknowledgment != null) {
			System.out.println("IN Acknowledgment provided");
			acknowledgment.acknowledge();
		}
	}

}
