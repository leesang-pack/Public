package com.gauravg.model;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

//interface
public interface MessageBinder {

	String PROCESS_OUT = "process-out";
    String PROCESS_IN = "process-in";

	@Output(PROCESS_OUT)
	MessageChannel createMessage();

	@Input(PROCESS_IN)
	SubscribableChannel messagePush();
}