package com.gauravg.controller;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.gauravg.model.MessageBinder;
import com.gauravg.model.TargetUserBinder;
import com.gauravg.util.CompletableFutureReplyingKafkaOperations;
import com.gauravg.util.CompletableFutureReplyingKafkaTemplate;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.ApiException;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
//import org.springframework.integration.support.MessageBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.requestreply.RequestReplyFuture;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.MimeTypeUtils;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.bind.annotation.*;

import com.gauravg.model.Model;
import org.springframework.web.context.request.async.DeferredResult;

@RestController
@Component
public class SumController {
	
	@Autowired
	ReplyingKafkaTemplate<String, Model,Model> kafkaTemplate;

	@Value("${kafka.topic.request-topic}")
	String requestTopic;

	@Value("${kafka.topic.request-topic2}")
	String requestTopic2;

	@Value("${kafka.topic.requestreply-topic}")
	String requestReplyTopic;

//	@Autowired
//	CompletableFutureReplyingKafkaOperations<String, Model, Model> replyKafkaTemplate;


	//////////////////////////////////////////////////////
	// Stream
	@Autowired
	private TargetUserBinder productsBinding;

	@Autowired
	private MessageBinder messageBinder;

	@PostMapping(value="/stream",produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public void sendProduct(@RequestBody final Model model) {

		System.out.println("----------------------------- CLIENT SEND STREAM " + model);
		productsBinding.targetSearch()
				.send(MessageBuilder.withPayload(model)
									.setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON)
									.build());
	}
	// Stream END

	private TopicPartition getFirstAssignedReplyTopicPartition() {
		if (kafkaTemplate.getAssignedReplyTopicPartitions() != null &&
				kafkaTemplate.getAssignedReplyTopicPartitions().iterator().hasNext()) {
			TopicPartition replyPartition = kafkaTemplate.getAssignedReplyTopicPartitions().iterator().next();
//			if (this.logger.isDebugEnabled()) {
//				this.logger.debug("Using partition " + replyPartition.partition());
//			}
			return replyPartition;
		} else {
			throw new KafkaException("Illegal state: No reply partition is assigned to this instance");
		}
	}

	private static byte[] intToBytesBigEndian(final int data) {
		return new byte[] {(byte) ((data >> 24) & 0xff), (byte) ((data >> 16) & 0xff),
				(byte) ((data >> 8) & 0xff), (byte) ((data >> 0) & 0xff),};
	}
	//////////////////////////////////////////////////////
	// Sync send
	@ResponseBody
	@PostMapping(value="/sum",produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public Model sum(@RequestBody Model request) throws InterruptedException, ExecutionException {
		// create producer record
		ProducerRecord<String, Model> record = new ProducerRecord<String, Model>(requestTopic, request);

//		TopicPartition replyPartition = getFirstAssignedReplyTopicPartition();
//		record.headers()
//				.add(new RecordHeader(KafkaHeaders.REPLY_TOPIC, replyPartition.topic().getBytes()))
//				.add(new RecordHeader(KafkaHeaders.REPLY_PARTITION, intToBytesBigEndian(replyPartition.partition())));

		System.out.println("--------------------------------------CLIENT REQUEST-----------");

		// set reply topic in header
		record.headers().add(new RecordHeader(KafkaHeaders.REPLY_TOPIC, requestReplyTopic.getBytes()));
		// post in kafka topic
		RequestReplyFuture<String, Model, Model> sendAndReceive = kafkaTemplate.sendAndReceive(record);

		// confirm if producer produced successfully
		SendResult<String, Model> sendResult = sendAndReceive.getSendFuture().get();

		System.out.println("-------->>>::: " + record);
		//
//		//print all headers
//		sendResult.getProducerRecord().headers().forEach(header -> System.out.println(header.key() + ":" + header.value().toString()));

		// get consumer record
		ConsumerRecord<String, Model> consumerRecord = sendAndReceive.get();

		// return consumer value
		System.out.println("--------------------------------------CLIENT RETURN-----------" + consumerRecord.value().getFirstNumber());
		return consumerRecord.value();
	}
	// Sync send END

	//////////////////////////////////////////////////////
	// ASync send
	@ResponseBody
	@PostMapping(value="/shared",produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public Model shared(@RequestBody Model request) throws InterruptedException, ExecutionException {
		// create producer record
		ProducerRecord<String, Model> record = new ProducerRecord<String, Model>(requestTopic2, request);

		System.out.println("--------------------------------------CLIENT SHARED REQUEST-----------");

		// set reply topic in header
		// post in kafka topic
		ListenableFuture<SendResult<String, Model>> future = kafkaTemplate.send(record);

		future.addCallback((ListenableFutureCallback<? super SendResult<String, Model>>) new ListenableFutureCallback<SendResult<String, Model>>() {
			@Override
			public void onFailure(Throwable ex) {
				System.out.println("----------------------------- CLIENT SEND RETURN Success ");
			}

			@Override
			public void onSuccess(SendResult<String, Model> result) {
				System.out.println("----------------------------- CLIENT SEND RETURN Success ");
			}
		});

		// return consumer value
		return null;
	}
//	 ASync send END

	//////////////////////////////////////////////////////
	// Sync send
//	@ResponseBody
//	@PostMapping(value="/sam",produces=MediaType.APPLICATION_JSON_VALUE)
//	public DeferredResult<Model> sum2(@RequestBody Model request) throws InterruptedException, ExecutionException {
//		Model model = null;
//
//		DeferredResult<Model> result = new DeferredResult<>();
//		CompletableFuture<Model> reply = replyKafkaTemplate.requestReply(requestTopic, request);
//		reply.thenAccept(car -> {
//
//			result.setResult(car);
//			Model model1 = (Model) result.getResult();
//			System.out.println("=========> " + model1.getFirstNumber());
////			return result;
//
//		}).exceptionally(ex -> {
//			result.setResult(new Model());
////			result.setErrorResult(new ApiException(HttpStatus.NOT_FOUND.toString(), ex.getCause()));
//			return null;
//		});
//
//		return result;
//	}
	// Sync send END

}
