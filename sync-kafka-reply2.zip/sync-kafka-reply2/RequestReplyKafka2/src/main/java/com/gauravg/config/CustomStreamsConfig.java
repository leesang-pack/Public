package com.gauravg.config;

import com.gauravg.model.MessageBinder;
import com.gauravg.model.TargetUserBinder;
import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(value= {TargetUserBinder.class, MessageBinder.class})
public class CustomStreamsConfig {
}
