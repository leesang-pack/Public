package com.gauravg.model;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

//interface
public interface TargetUserBinder {

	String TARGET_OUT = "target-out";
    String TARGET_IN = "target-in";

    //outbound : Kafka 토픽에 메시지를 쓰는 데 사용되는 출력 스트림
	//전송 채널 정의 @Output주석 지정하고, 출력 지정된 이름의 결합.
	@Output(TARGET_OUT)
	MessageChannel targetSearch();

	//inbound : kafka 메시지를 소비하는 데 사용되는 입력 스트림입니다.
	@Input(TARGET_IN)
	SubscribableChannel targetFilter();
}