package com.gauravg.config;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import com.gauravg.util.CompletableFutureReplyingKafkaOperations;
import com.gauravg.util.CompletableFutureReplyingKafkaTemplate;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
//import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;

import com.gauravg.model.Model;

@Configuration
@EnableKafka
public class KafkaConfig {

	@Value("${kafka.bootstrap-servers}")
	private String bootstrapServers;

	@Value("${kafka.topic.requestreply-topic}")
	private String requestReplyTopic;

	@Value("${kafka.consumergroup}")
	private String consumerGroup;

	@Bean
	public Map<String, Object> producerConfigs() {
		Map<String, Object> props = new HashMap<>();
		// list of host:port pairs used for establishing the initial connections to the Kakfa cluster
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,	bootstrapServers);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
   		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		return props;
	}

	@Bean
	public Map<String, Object> consumerConfigs() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrapServers);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroup);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
//		props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, autoCommitInterval);
//		props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "5000");
		props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "60000");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		return props;
	}

	@Bean
	public ProducerFactory<String, Model> producerFactory() {
		return new DefaultKafkaProducerFactory<>(producerConfigs());
	}


	@Bean
	public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, Model>> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, Model> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		factory.setReplyTemplate(kafkaTemplate());
		factory.setConcurrency(1);
		factory.getContainerProperties().setPollTimeout(1500);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE) ;
		return factory;
	}


	@Bean
	public ConsumerFactory<String, Model> consumerFactory() {
		return new DefaultKafkaConsumerFactory<>(consumerConfigs(),new JsonDeserializer(),new JsonDeserializer<>(Model.class));
	}


	@Bean
	public KafkaTemplate<String, Model> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}


	@Bean
	public KafkaMessageListenerContainer<String, Model> replyContainer(ConsumerFactory<String, Model> cf) {
		ContainerProperties containerProperties = new ContainerProperties(requestReplyTopic);
		return new KafkaMessageListenerContainer<>(cf, containerProperties);
	}

	@Bean
	public ReplyingKafkaTemplate<String, Model, Model> replyKafkaTemplate(ProducerFactory<String, Model> pf, KafkaMessageListenerContainer<String, Model> container){
		ReplyingKafkaTemplate template = new ReplyingKafkaTemplate<>(pf, container);
		return template;
	}

//	@Bean
//	public CompletableFutureReplyingKafkaOperations<String, Model, Model> replyKafkaTemplate(ProducerFactory<String, Model> pf, KafkaMessageListenerContainer<String, Model> container) {
//		CompletableFutureReplyingKafkaTemplate<String, Model, Model> requestReplyKafkaTemplate = new CompletableFutureReplyingKafkaTemplate<>(pf, container);
//		return requestReplyKafkaTemplate;
//	}
//	@Bean
//	public KafkaMessageListenerContainer<String, Model> replyListenerContainer(ConsumerFactory<String, Model> cf) {
//		ContainerProperties containerProperties = new ContainerProperties(requestReplyTopic);
//		return new KafkaMessageListenerContainer<>(cf, containerProperties);
//	}

	//Model END

//	@Bean
//	public ReplyingKafkaTemplate<String, Model, Model> replyKafkaTemplate(ProducerFactory<String, Model> pf) {
//
//
//		ContainerProperties containerProperties = new ContainerProperties("replies");
//		final CountDownLatch latch = new CountDownLatch(1);
//		containerProperties.setConsumerRebalanceListener(new ConsumerRebalanceListener() {
//
//			@Override
//			public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
//				// no op
//			}
//
//			@Override
//			public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
//				latch.countDown();
//			}
//
//		});
//
//		DefaultKafkaConsumerFactory<Integer, String> cf = new DefaultKafkaConsumerFactory<>(consumerConfigs());
//
//		KafkaMessageListenerContainer<Integer, String> container = new KafkaMessageListenerContainer<>(cf,
//				containerProperties);
//
//		container.setBeanName("requestreplygorup");
//		ReplyingKafkaTemplate<String, Model, Model> replyingKafkaTemplate = new ReplyingKafkaTemplate(pf, container);
//		replyingKafkaTemplate.setSharedReplyTopic(true);
//		replyingKafkaTemplate.start();
//
//		return replyingKafkaTemplate;
//	}

//	@Bean
//	public KafkaMessageListenerContainer<String, Model> replyContainer(ConsumerFactory<String, Model> cf) {
//		ContainerProperties containerProperties = new ContainerProperties(requestReplyTopic);
//		return new KafkaMessageListenerContainer<>(cf, containerProperties);
//	}

//	@Bean
//	ConcurrentKafkaListenerContainerFactory<String, Model> kafkaListenerContainerFactory() {
//		ConcurrentKafkaListenerContainerFactory<String, Model> factory = new ConcurrentKafkaListenerContainerFactory<>();
//		factory.setConsumerFactory(consumerFactory());
//		factory.setReplyTemplate(kafkaTemplate());
//		factory.setConcurrency(1);
//		factory.getContainerProperties().setPollTimeout(1500);
//		factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE) ;
//		return factory;
//	}
//
//	@Bean
//	public ConcurrentMessageListenerContainer<String, Model> repliesContainer(ConcurrentKafkaListenerContainerFactory<String, Model> containerFactory) {
//
//
//		ConcurrentMessageListenerContainer<String, Model> repliesContainer = containerFactory.createContainer("replies");
//		repliesContainer.getContainerProperties().setGroupId("group");
//		repliesContainer.setAutoStartup(true);
//		return repliesContainer;
//	}


//	@Bean
//	public KafkaMessageListenerContainer<String, String> replyContainer(ConsumerFactory<String, String> cf) {
//		ContainerProperties containerProperties = new ContainerProperties(requestReplyTopic);
//		return new KafkaMessageListenerContainer<>(cf, containerProperties);
//	}
//
//	  @Bean
//	  public ConsumerFactory<String, String> consumerFactory() {
//	    return new DefaultKafkaConsumerFactory<String,String>(consumerConfigs(),new StringDeserializer(),new StringDeserializer());
//	  }
//
//	@Bean
//	public ProducerFactory<String,String> producerFactory() {
//		return new DefaultKafkaProducerFactory<>(producerConfigs());
//	}
//
//        @Bean
//        public KafkaTemplate<String, String> kafkaTemplate() {
//            return new KafkaTemplate<>(producerFactory());
//        }
//
//
//	@Bean
//	public ReplyingKafkaTemplate<String, String, String> replyingTemplate(ProducerFactory<String, String> producerFactory, ConcurrentMessageListenerContainer<String, String> repliesContainer) {
//
//		return new ReplyingKafkaTemplate<>(producerFactory, repliesContainer);
//	}
//
//	@Bean
//	public ConcurrentMessageListenerContainer<String, String> repliesContainer(ConcurrentKafkaListenerContainerFactory<String, String> containerFactory) {
//
//		ConcurrentMessageListenerContainer<String, String> repliesContainer = containerFactory.createContainer("requestreply-topic2");
//		repliesContainer.getContainerProperties().setGroupId("requestreplygorup");
//		repliesContainer.setAutoStartup(false);
//		return repliesContainer;
//	}
//
//	@Bean
//	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
//	  	ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
//		factory.setConsumerFactory(consumerFactory());
//		factory.setReplyTemplate(kafkaTemplate());
//		factory.setReplyHeadersConfigurer((k, v) -> k.equals("requestreply-topic2"));
//		return factory;
//	}
}

