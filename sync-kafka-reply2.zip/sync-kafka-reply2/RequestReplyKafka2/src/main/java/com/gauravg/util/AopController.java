package com.gauravg.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Copyright (c) 2012-2020 GoodMorning Itec, Inc. All Rights Reserved.
 * Created by oem:selee on 20. 1. 14.
 */
@Aspect
@Component
public class AopController {

    @Before("execution(* org.springframework.messaging.MessageChannel.send(..)) && args(org.springframework.messaging.Message)")
    public void logBefore(JoinPoint joinPoint) throws JsonProcessingException {
        Message<?> message = (Message<?>) joinPoint.getArgs()[0];
        System.out.println("hello =========================== > send !! ::" + message.getPayload() + " " + message.getHeaders());
    }

    @Around("@annotation(org.springframework.cloud.stream.annotation.StreamListener)")
    public void logBefore2(ProceedingJoinPoint joinPoint) throws JsonProcessingException {

        Message<?> message = (Message<?>) joinPoint.getArgs()[0];


        System.out.println("hello ==================>>> before listener 2:: " + message.getPayload() + " " + message.getHeaders());
        try {
            joinPoint.proceed();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        System.out.println("hello ==================>>> listener 2:: " + message.getPayload() + " " + message.getHeaders());
    }
    @Around("@annotation(org.springframework.cloud.stream.annotation.StreamListener)")
    public void logBefore3(ProceedingJoinPoint joinPoint) throws JsonProcessingException {

        Message<?> message = (Message<?>) joinPoint.getArgs()[0];

        System.out.println("hello ==================>>> before listener333 :: " + message.getPayload() + " " + message.getHeaders());

        try {
            joinPoint.proceed();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        System.out.println("hello ==================>>> listener333 :: " + message.getPayload() + " " + message.getHeaders());
    }
    /**
     * kr.goodmit.framework.api.* package에서 실행하는 Process에 대한 Start, End Time 체크
     * 'within' 옵션을 사용하여 'RestController'어노테이션을 가지고 있는 Controller에 대한 실행 그외에 필요한
     * execution, target, this 등은 옵션으로 선택 가능.
     *
     * @param joinPoint
     * @return
     * @throws Throwable
     */
//	@Around("execution(* kr.goodmit.framework.api..*.*(..)) && @annotation(org.springframework.web.bind.annotation.RestController)")
    @Around("@within(org.springframework.web.bind.annotation.RestController)")
    public Object executeArroundMethod(ProceedingJoinPoint joinPoint) throws Throwable {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();

        System.out.println("******************** LOGGING START [ Requset URL : {} ] ********************"+ request.getRequestURI());

        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

        String reqTime = df.format(System.currentTimeMillis());
        StopWatch stopWatch = new StopWatch();
        stopWatch.start(); // 전체시간 체크 - 시작

        // 메소드 실행
        Object result = joinPoint.proceed();

        stopWatch.stop(); // 전체시간 체크 - 중지
        String rspTime = df.format(System.currentTimeMillis());
        long totalTimeMillis = stopWatch.getTotalTimeMillis();
        System.out.println("******************** LOGGING END [ Requset URL : {} ] ********************"+ request.getRequestURI());

        return result;
    }
}
