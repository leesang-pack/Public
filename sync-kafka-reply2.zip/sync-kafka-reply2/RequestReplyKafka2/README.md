```$xslt
#############################
# sync error case test
# env : partition 2                                 (server)'s
#    (client)'s                     |-- consumer1 group(requestreplygorup)   --|  rb(active p0) error-|
#   producer1 send sync --->        |-- consumer2 group(requestreplygorup)   --|  rb(active p1) error-|
#                      (kafka topic)|
#                          topic  --|-- consumer3 group(requestreplygorup1)  --|  rb(active p0) error msg : using a shared reply topic
#                                   |-- consumer4 group(requestreplygorup1)  --|  rb(active p1) error-|
#                                                                                                     |
#        <--- requestreply-topic1 ---------------------------------------------------------------------
#   producer2


#############################
# sync normal case test
# env : partition 2
#    (client)'s        (kafka topic)                (server)'s
#   producer1 send sync ----|
#                           v
#                          topic  --|-- consumer1 group(requestreplygorup)   --|  rb(active p0)   -|    (active p0,p1)
#                           ^       |-- consumer2 group(requestreplygorup)   --|  rb(active p1)   -|    (not active)
#                           |       |-- consumer3 group(requestreplygorup)   --|  (stand-by)      -|    (not active)
#                           |                                                                      |
#        <--- requestreply-topic1 ------------------------------------------------------------------
#   producer2 send sync ----|                                                                      |
#                                                                                                  |
#                                                                                                  |
#        <--- requestreply-topic2 ------------------------------------------------------------------
#   producer3 send p0   ----|           consumer1 only p0                                          |
#                                                                                                  |
#                                                                                                  |
#        <--- requestreply-topic2 ------------------------------------------------------------------


#############################
# env : partition 2
# group broadcast test                              (server)'s
#    (client)'s                     |-- consumer1 group(requestreplygorup)   --|  rb(active p0)
#   producer1 send async --->       |-- consumer2 group(requestreplygorup)   --|  rb(active p1)
#                      (kafka topic)|                                                             offset stack up     run stack but not sequence 비동기니 순서가 보장되지 않음.
#                          topic2 --|-- consumer3 group(requestreplygorup1)  --|  only(active p0) -> (not run) -> only(active p0)
#                                   |-- consumer4 group(requestreplygorup1)  --|  (not run)

#############################
# env : partition 2
# stream test
#    (client)'s                                     (server)'s   
#   producer1  --->                            |-- consumer1 group(targetGroup)    --|  rb(active p0)--|
#               (channel name)    (kafka topic)|-- consumer2 group(targetGroup)    --|  rb(active p1)--|                          (channel name) 
#       target-out send async--->  targets3 ---|                                                     --|-->StreamListener            target-in
#                             |                                                                                                          |
#                             |                                                                                                          |  stream blar blar processing..
#                             |                                                                            (kafka topic)                 v                                        
#                             |                |-- consumer1 group(processGroup)  --|  rb(active p0) --|--- process3        <----- process-out send async
#                 process-in  StreamListener<--|-- consumer2 group(processGroup)  --|  rb(active p1) --|                       |
#                      |      |                                                                                                |
#           stream blar blar last processing..                                                                                 |
############################# |                                                                                                |
# env: partition 2            |                                                                                                |
# stream group broadcast test |                                                                                                |
#                             |                |-- consumer3 group(targetGroup1)   --|  rb(active p0)--|                       |
#                             |   (kafka topic)|-- consumer4 group(targetGroup1)   --|  rb(active p1)--|                       |  (channel name) 
#                             -->  targets3 ---|                                                     --|-->StreamListener      |     target-in
#                                                                                                                              |        |
#                                                                                                                              |        |-> stream blar blar processing..
#                                              |-- consumer3 group(processGroup1) --|  rb(active p0) --|--- process3        <--|
#                 process-in  StreamListener<--|-- consumer4 group(processGroup1) --|  rb(active p1) --|
#                      |             
#           stream blar blar last processing..
```